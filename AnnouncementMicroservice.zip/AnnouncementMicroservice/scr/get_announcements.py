import json
from announcementService import listAllAnnouncementsByLimit,listAnnouncementsById,getResponse,listAllAnnouncementsByIndex

def listAllAnnouncements(event):
    try:
        id = ''
        limit = 10
        if ('id' in event['params']['querystring']):
                id = event['params']['querystring']["id"]
   
        if ('limit' in event['params']['querystring']):
                announcementsLimit = (event['params']['querystring']['limit'])
                #check if limit is grater than 0 , if not raise exception
                if (announcementsLimit == '0'):
                    raise Exception('limit value should be greater than zero')
                limit = int(announcementsLimit)
                
                
        if id == '':
                if ('index' in event['params']['querystring']):
                    indexValue = (event['params']['querystring']['index'])
                    indexId = {}
                    indexId['announcementId'] = indexValue
                    response = listAllAnnouncementsByIndex(limit,indexId);
                else:
                    response = listAllAnnouncementsByLimit(limit);
                if ('LastEvaluatedKey' in response):
                    lastEvaluatedKey = response['LastEvaluatedKey']
                    print ("lastEvaluatedKey",lastEvaluatedKey)
                else:
                    lastEvaluatedKey = None
                
                print("lastEvaluatedKey --",lastEvaluatedKey)
                formResponse = getResponse(response['Items'])
                
                #Construct response Data
                result = {}
                result['data'] = formResponse
                    
                #Construct MetaData
                metaData = {}
                metaData['Count'] = len(response['Items'])
                metaData['LastEvaluatedKey'] = lastEvaluatedKey
                            
                result['meta'] = metaData
     
        else:
                response = listAnnouncementsById(id);
                formResponse = getResponse(response)
                result = formResponse
                
        return result
    
    except Exception as exp:
        print ("Ex",exp)
        return{
            "FunctionError": exp
        }
    