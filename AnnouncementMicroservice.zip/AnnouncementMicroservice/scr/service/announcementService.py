import json
import os
import boto3
dynamodb = boto3.resource('dynamodb')
from boto3.dynamodb.conditions import Key
tablename = dynamodb.Table('AnnouncementsTable')

def storeAnnouncement(id,title,description,currentDate):
    try:
        #retrieving tablename of dynamodb table
        print('id',id)
        response  = tablename.put_item(
            Item={
                'announcementId' : id,
                'title': title,
                'description' : description,
                'date' : currentDate
            }
        )
        response = tablename.get_item(Key={'announcementId': id})
        return response['Item']
        
    except Exception as exp:
        return{
                "FunctionError": exp
        }
        
def listAllAnnouncementsByLimit(limit):
	try:
		#retrieving all announcements from dynamo db table
		response = tablename.scan(Limit = limit)
		return response
	except Exception as exp:
		return{
			"FunctionError": exp
        }
def listAllAnnouncementsByIndex(limit,indexId):
	try:
		#retrieving all announcements from dynamo db table
		response = tablename.scan(ExclusiveStartKey = indexId,Limit=limit)
		return response
	except Exception as exp:
		return{
			"FunctionError": exp
        }
def listAnnouncementsById (id):
    try:
        response = tablename.get_item(Key={'announcementId': id})
        response = response['Item']
        output ={
                'announcementId' :response["announcementId"],
                'title': response["title"],
                'description' : response["description"],
                'date' : response["date"]
            }
        return {"data": output}
        
    except Exception as exp:
        return{
                "FunctionError": exp
        }
def getResponse (response):
    try:
        print('response',response)
        value = []
        for s in range(len(response)):
            output ={
                'announcementId' :response[s]["announcementId"],
                'title': response[s]["title"],
                'description' : response[s]["description"],
                'date' : response[s]["date"]
            }
            value.append(output)
            
         
        return value
    except Exception as exp:
        print (str(exp))
        return{
                "FunctionError": exp
        }