import json
from post_announcement import createAnnouncement
from get_announcements import listAllAnnouncements

def lambda_handler(event, context):
    try:
        #call create announcement function to create an announcement
        http_method = event['context']['http-method']

        response_code = 200

        if http_method == 'GET':
            response  = listAllAnnouncements(event)
            result =response
    
        elif http_method == 'POST':
            response  = createAnnouncement(event)
            result =response
        else:
            result = f"Sorry, {name} - Method {http_method} isn't allowed."
            response_code = 405
            
        return result
    except Exception as exp:
        return{
            "FunctionError": exp
        }