package com.order.model;


import lombok.Data;
import user.User;

import java.util.List;

@Data
public class Customer {
    private String email;
    private String full_name;
    private String shipping_address;
    private String credit_card_number;
    private String credit_card_type;
    private String password;
    private String country;
    private String product_pid;
    private Integer quantity;
    private String first_name;
    private String last_name;
    private String supplier_pid;
    private String date_created;
    private String order_status;

}