package com.order.service;

import com.google.protobuf.StringValue;
import com.google.rpc.context.AttributeContext;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.exceptions.CsvException;
import com.order.grpc.OrderServiceClient;
import com.order.grpc.UserServiceClient;
import com.order.model.Customer;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import order.CreateOrderRequest;
import order.Order;
import org.springframework.beans.factory.annotation.Autowired;
import user.User;
import user.UserServiceGrpc;

import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@GrpcService
public class CreateUserService extends UserServiceGrpc.UserServiceImplBase {

    @Autowired
    UserServiceClient userServiceClient;


    private String userPid;

    @Override
    public void createUser(User.CreateUserRequest request, StreamObserver<User.UserResponse> responseObserver) {

        try {
            Integer productIndex = 0;
            List<Customer> data = readCSV();
            data.forEach(row -> {

                User.ShippingAddress address = User.ShippingAddress.newBuilder()
                        .setAddress(StringValue.of(row.getShipping_address()))
                        .setCountry(StringValue.of(row.getCountry()))
                        .build();

                User.PaymentMethod paymentMethods = User.PaymentMethod.newBuilder()
                                .setCreditCardNumber(StringValue.of(row.getCredit_card_number()))
                                .setCreditCardType(StringValue.of(row.getCredit_card_type()))
                                .build();

                User.CreateUserRequest.newBuilder()
                        .setFullName(StringValue.of(row.getFull_name()))
                        .setEmail(row.getEmail())
                        .setAddress(address)
                        .addAllPaymentMethods(Collections.singleton(paymentMethods))
                        .setPassword(StringValue.of(UUID.randomUUID().toString()))
                        .build();
                User.UserResponse response = userServiceClient.createUser(request);
                this.userPid = response.getPid();

                responseObserver.onNext(response);
                responseObserver.onCompleted();
            });
        }catch(IOException | CsvException e){
            e.getMessage();
        }



    }

    public List<Customer> readCSV() throws IOException, CsvException {
        String filePath = "bootstrap/integration/order-integration.csv";
        try (CSVReader csvReader = new CSVReader( new FileReader(filePath)))
        {
            CsvToBean<Customer> csvToBean = new CsvToBeanBuilder<Customer>(csvReader)
                    .withType(Customer.class)
                    .withIgnoreLeadingWhiteSpace(true) .build();
            return csvToBean.parse();
        }
    }


}
