package com.order.service;

import net.devh.boot.grpc.server.service.GrpcService;
import order.OrderServiceGrpc;

@GrpcService
public class OrderProcessingService extends OrderServiceGrpc.OrderServiceImplBase {
}
