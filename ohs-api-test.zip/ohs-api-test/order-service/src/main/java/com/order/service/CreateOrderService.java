package com.order.service;

import com.google.protobuf.StringValue;
import com.order.grpc.OrderServiceClient;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import order.CreateOrderRequest;
import order.OrderResponse;
import order.OrderServiceGrpc;
import org.springframework.beans.factory.annotation.Autowired;

@GrpcService
public class CreateOrderService extends OrderServiceGrpc.OrderServiceImplBase {

    @Autowired
    OrderServiceClient orderServiceClient;

    @Override
    public void createOrder(CreateOrderRequest request, StreamObserver<OrderResponse> responseObserver) {

        order.Product product = order.Product.newBuilder()
                .setPid(row.getProduct_pid())
                .setQuantity(row.getQuantity())
                .setPricePerUnit(30.00)
                .build();

        order.OrderResponse orderResponse = orderServiceClient.createOder(CreateOrderRequest.newBuilder()
                .setUserPid(userPid)
                .setDateCreated(StringValue.of(row.getDate_created()))
                .setDateDelivered(StringValue.of(row.getDate_created()))
                .setStatus(order.OrderStatus.valueOf(row.getOrder_status()))
                .setPricePerUnit(33.00f)
                .setQuantity(1)
                .setProducts(productIndex ,product)
                .build());

        orderResponse.getPid()
    }


}
