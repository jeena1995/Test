package com.order.grpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import user.User;
import user.UserServiceGrpc;

@Configuration
@ComponentScan("com.order")
public class UserServiceClient {

    private final UserServiceGrpc.UserServiceBlockingStub blockingStub;

    public UserServiceClient() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50054)
                .usePlaintext()
                .build();
        blockingStub = UserServiceGrpc.newBlockingStub(channel);
    }

    public User.UserResponse createUser(User.CreateUserRequest request) {
        System.out.println("reached client");
        User.UserResponse response = blockingStub.createUser(request);
        System.out.println("response");
        return response;
    }
}