package com.order.service;

import com.opencsv.exceptions.CsvException;
import com.order.config.CsvOrderReader;
import com.order.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

@Component
public class UserCsvRunner implements CommandLineRunner {
    @Autowired
    private CsvOrderReader csvService;

    @Override
    public void run(String... args) throws IOException, CsvException {
        List<Customer> data = csvService.readCSV();

        // Process the data as needed
        data.forEach(row -> {
        });
    }
}
