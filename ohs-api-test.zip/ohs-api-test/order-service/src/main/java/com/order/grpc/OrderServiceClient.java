package com.order.grpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import order.CreateOrderRequest;
import order.Order;
import order.OrderResponse;
import order.OrderServiceGrpc;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import user.User;
import user.UserServiceGrpc;

@Configuration
public class OrderServiceClient {

    private final OrderServiceGrpc.OrderServiceBlockingStub blockingStub;

    public OrderServiceClient() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50054)
                .usePlaintext()
                .build();
        blockingStub = OrderServiceGrpc.newBlockingStub(channel);
    }


    public OrderResponse createOder(CreateOrderRequest orderRequest) {
        OrderResponse response = blockingStub.createOrder(orderRequest);
        return response;
    }


}