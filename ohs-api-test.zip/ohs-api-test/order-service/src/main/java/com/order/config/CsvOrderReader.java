package com.order.config;

import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.exceptions.CsvException;
import com.order.model.Customer;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

@Service
public class CsvOrderReader {

        public List<Customer> readCSV() throws IOException, CsvException {
            String filePath = "bootstrap/integration/order-integration.csv";
                try (CSVReader csvReader = new CSVReader( new FileReader(filePath)))
                {
                    CsvToBean<Customer> csvToBean = new CsvToBeanBuilder<Customer>(csvReader)
                            .withType(Customer.class)
                            .withIgnoreLeadingWhiteSpace(true) .build();
                    return csvToBean.parse();
                }
        }
}


